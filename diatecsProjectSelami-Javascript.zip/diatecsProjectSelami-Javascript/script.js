const canvas = document.getElementById("zooCanvas");
const ctx = canvas.getContext("2d");

const speciesColors = {
  sheep: "lightgray",
  cow: "brown",
  chicken: "yellow",
  rooster: "orange",
  wolf: "black",
  lion: "gold",
  hunter: "red",
};

let animals = [];

function createAnimal(species, gender) {
  return {
    species,
    gender,
    x: Math.random() * 500,
    y: Math.random() * 500,
    alive: true,
  };
}

function initAnimals() {
  animals = [];
  for (let i = 0; i < 15; i++) animals.push(createAnimal("sheep", "male"));
  for (let i = 0; i < 15; i++) animals.push(createAnimal("sheep", "female"));
  for (let i = 0; i < 5; i++) animals.push(createAnimal("cow", "male"));
  for (let i = 0; i < 5; i++) animals.push(createAnimal("cow", "female"));
  for (let i = 0; i < 10; i++) animals.push(createAnimal("chicken", "female"));
  for (let i = 0; i < 10; i++) animals.push(createAnimal("rooster", "male"));
  for (let i = 0; i < 5; i++) animals.push(createAnimal("wolf", "male"));
  for (let i = 0; i < 5; i++) animals.push(createAnimal("wolf", "female"));
  for (let i = 0; i < 4; i++) animals.push(createAnimal("lion", "male"));
  for (let i = 0; i < 4; i++) animals.push(createAnimal("lion", "female"));
  animals.push(createAnimal("hunter", "none"));
}

function move(animal) {
  const steps = {
    sheep: 2, cow: 2, wolf: 3,
    chicken: 1, rooster: 1,
    lion: 4, hunter: 1
  };
  const step = steps[animal.species] || 1;
  const angle = Math.random() * 2 * Math.PI;
  animal.x = Math.max(0, Math.min(500, animal.x + Math.cos(angle) * step));
  animal.y = Math.max(0, Math.min(500, animal.y + Math.sin(angle) * step));
}

function distance(a1, a2) {
  return Math.hypot(a1.x - a2.x, a1.y - a2.y);
}

function reproduce() {
  const groups = {};

  animals.forEach(a => {
    if (!a.alive || a.species === "hunter") return;
    let species = a.species === "rooster" ? "chicken" : a.species;
    if (!groups[species]) groups[species] = { male: [], female: [] };
    groups[species][a.gender]?.push(a);
  });

  const newAnimals = [];

  for (let species in groups) {
    const males = groups[species].male;
    const females = groups[species].female;
    for (let f of females) {
      for (let m of males) {
        if (distance(f, m) <= 3) {
          const gender = Math.random() < 0.5 ? "male" : "female";
          let sp = species;
          if (species === "chicken") {
            sp = gender === "female" ? "chicken" : "rooster";
          }
          newAnimals.push(createAnimal(sp, gender));
          break;
        }
      }
    }
  }

  animals.push(...newAnimals);
}

function hunt() {
  for (let predator of animals) {
    if (!predator.alive) continue;

    let preySpecies = [];
    let radius = 0;

    if (predator.species === "wolf") {
      preySpecies = ["sheep", "chicken", "rooster"];
      radius = 4;
    } else if (predator.species === "lion") {
      preySpecies = ["sheep", "cow"];
      radius = 5;
    } else if (predator.species === "hunter") {
      preySpecies = ["sheep", "cow", "chicken", "rooster", "wolf", "lion"];
      radius = 8;
    }

    for (let prey of animals) {
      if (prey.alive && prey !== predator && preySpecies.includes(prey.species)) {
        if (distance(predator, prey) <= radius) {
          prey.alive = false;
        }
      }
    }
  }
}

function drawAnimals() {
  ctx.clearRect(0, 0, 500, 500);
  animals.forEach(a => {
    if (!a.alive) return;
    ctx.fillStyle = speciesColors[a.species] || "gray";
    ctx.beginPath();
    ctx.arc(a.x, a.y, 3, 0, Math.PI * 2);
    ctx.fill();
  });
}

function simulateStep(step = 0) {
  animals.forEach(a => a.alive && move(a));
  reproduce();
  hunt();
  drawAnimals();

  if (step < 1000) {
    requestAnimationFrame(() => simulateStep(step + 1));
  } else {
    summarize();
  }
}

function summarize() {
  const count = {};
  animals.forEach(a => {
    if (a.alive) count[a.species] = (count[a.species] || 0) + 1;
  });
  console.log("1000 Adım Sonunda Popülasyon:");
  Object.entries(count).forEach(([sp, val]) => {
    console.log(`${sp}: ${val}`);
  });
}

initAnimals();
simulateStep();
